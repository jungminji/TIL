/*! ui/tab.js @ 2017, yamoo9.net */
(function(global){
  'use strict';

})(window);